package prueba_correo;

import correos.EnviarConAdjunto;
import correos.EnviarCorreoBasico;
import correos.EnviarGmail;

public class Main {

	public static void main(String[] args) throws Exception {
		
		//EnviarConAdjunto.enviarMensaje("juan.garcia@confiar.com.co", "juan.garcia@confiar.com.co");
		
		//EnviarCorreoBasico.main(args);
		//EnviarGmail.enviarMensaje("juan.garcia@confiar.com.co");
	}

}
